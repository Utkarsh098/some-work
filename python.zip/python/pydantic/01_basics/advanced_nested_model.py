from pydantic import BaseModel
from typing import List, Optional

class Address(BaseModel):
    street: str
    city: str
    pincode: str
    
class Company(BaseModel):
    name: str
    address: Optional['Address']= None
    
class Employee(BaseModel):
    id: int
    name: str
    company: Company