from pydantic import computed_field, BaseModel, Field, field_validator
from typing import Optional

class Hotel_booking(BaseModel):
    id: int
    room_no: int
    price_per_night: float
    days: int = Field(
        ...,
        ge=1
    )
    
    @field_validator('days')
    def valid_no_of_stay_days(cls, v) ->int:
        if v<1:
            raise ValueError("No. of days should be greater than 1")
    
    @computed_field
    @property
    def total_price_calculated(self) -> float:
        return self.days*self.price_per_night