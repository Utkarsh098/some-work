from pydantic import field_validator, BaseModel, model_validator
from typing import Optional

class PasswordError(Exception): pass

class Student(BaseModel):
    id: int
    username: str
    subjects: Optional[list[str]]
    password: str
    confirm_password: str
    
    @field_validator('username')
    def username_length(cls, v:str):
        if len(v)<4:
            raise ValueError("Username length should be more than 4 characters.")
        return v
    
    @model_validator(mode='after')      #triggered AFTER the field validations are checked
    def password_matches_confirm_password(cls, values):
        if values.password!=values.confirm_password:
            raise PasswordError("Passwords Do not match")
        return values
        