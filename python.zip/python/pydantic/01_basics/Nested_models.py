from pydantic import BaseModel
class Address(BaseModel):
    street: str
    city: str
    postal_code: str
    
class User(BaseModel):
    id: int
    name: str
    address: Address
    
user = User.model_validate({
    "id":1,
    "name": "UttU",
    "address":{
        "street": "F1, B-32, Janki Nagar",
        "city":"Jodhpur",
        "postal_code": "342008"
    }
})

print(user)