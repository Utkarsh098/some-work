import datetime
from pydantic import field_validator, BaseModel, model_validator
from typing import Optional

class Person(BaseModel):
    firstname: str
    lastname: str
    
    @field_validator('firstname', 'lastname')
    def names_should_be_capitalized(cls, v:str):
        if not v.istitle():
            raise ValueError("Names must be capitalized")
        return v
    
class Product(BaseModel):
    price: str  # $4.44
    
    @field_validator('price', mode='before')
    def parse_price(cls, v):
        if isinstance(v, str):
            return float(v.strip().replace('$', ''))
        else: raise ValueError("Please enter the price in $")
        
        
class Date_Range(BaseModel):
    startdate: datetime
    enddate: datetime
    
    @model_validator(mode='after')
    def validate_date(cls, values: datetime):
        if values.startdate>=values.enddate:
            raise ValueError("End date should be after the start date")
        return values