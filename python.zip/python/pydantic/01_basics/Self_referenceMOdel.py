from pydantic import BaseModel
from typing import List, Optional

class Comment(BaseModel):
    id: int
    content: str
    replies: Optional[List['Comment']] = None
    
Comment.model_rebuild()


comment = Comment(
    id= 1,
    content= "First Comment",
    replies=[
        Comment(id=2, content="First reply", replies=None),
        Comment(id=3, content="Second Reply", replies=None)
    ]
)

print(comment)