from typing import Optional
from pydantic import BaseModel

class Product(BaseModel):
    id: int
    name: str
    items: list[str]
    quantities: dict[str, int]
    
class BlogPost(BaseModel):
    id: int
    title: str
    content: str
    imageUrl: Optional[str] = None
    
test_data={
    "id": 101,
    "name": "UttU",
    "items": ["Dal",
              "Chawal",
              "Paneer",
              "Soyabean",],
    "quantities": {"Dal":20, "Chawal":30, "Paneer": 50, "Soyabean": 35}
}

new_product = Product(**test_data)

print(new_product)