from typing import Optional
from pydantic import BaseModel, Field

class userModel(BaseModel):
    id: int
    name: str = Field(
        ...,
        min_length=3,
        max_length=50,
        examples="John Doe",
        description="Employee's name"
        )
    department: Optional[str] = "General",
    salary: float = Field(
        ...,
        ge=15000
    )
    
class User(BaseModel):
    email: str = Field(
        ...,
        regex = r''
    )