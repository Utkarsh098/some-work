from concurrent.futures import ProcessPoolExecutor
import asyncio

def encrypted_password(password):
    return (f"Hashed password: {password[::-1]}")

async def main():
    loop = asyncio.get_running_loop()
    with ProcessPoolExecutor() as pool:
        result = await loop.run_in_executor(pool, encrypted_password, entered)
        # print(result)
    
if __name__ == "__main__":
    entered = input("Enter the password to be hashed:\n")  
    asyncio.run(main())