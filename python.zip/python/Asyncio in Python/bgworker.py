import threading, asyncio, time

def backgroundworker():
    while True:
        time.sleep(1)
        print("Logging system health 🤖")
        
        
async def fetch_orders():
    await asyncio.sleep(3)
    print("order fetched 🎁")
    

#These both can run at the same time

threading.Thread(target=backgroundworker, daemon=True).start()

asyncio.run(fetch_orders())