import asyncio, aiohttp, time

# async def first_try_at_fetch_with_async(session, url):
#     async with session.get(url) as response:
#         return (f"Fetched {url} with the status code of {response.status}")
        
        
# async def main():
#     urls = ["https://httpbin.org/delay/2"]*8
#     async with aiohttp.ClientSession() as session:
#         tasks = [first_try_at_fetch_with_async(session, url) for url in urls]
#         results = await asyncio.gather(*tasks)
#         [print(f"{result}") for result in results]
        
        

# start = time.time()        
# asyncio.run(main())        
# end = time.time()

# print(f"Time took: {end-start:.2f}")