from concurrent.futures import ThreadPoolExecutor
import asyncio, time

def check_inventory(type_):
    print(f"Checking {type_} in the inventory...")
    time.sleep(3)
    return (f"{type_} found!!!")
    
async def main():
    loop = asyncio.get_running_loop()
    with ThreadPoolExecutor() as pool:
        result = await loop.run_in_executor(pool, check_inventory, "test")
        print(result)
        
asyncio.run(main())
    