import tiktoken

encoder = tiktoken.encoding_for_model("gpt-4o")

text= "Hey there I am UttU"

tokens = encoder.encode(text)
print(tokens)