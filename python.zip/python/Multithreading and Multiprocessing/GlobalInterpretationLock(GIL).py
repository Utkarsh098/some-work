import threading, time

def brewing_chai():
    print(f"{threading.current_thread().name} Started brewing chai...")
    
    count = 0
    for i in range(1_000_000):                      #mutex has the conrtol here, it wont let it run further unless this is completed
        count+=1
        
    print(f"{threading.current_thread().name} Ended brewing chai...")
    
#threads below:

thread1 = threading.Thread(target=brewing_chai, name="Barista 1")
thread2 = threading.Thread(target=brewing_chai, name="Barista 2")

start = time.time()
thread1.start()
thread2.start()
thread1.join()
thread2.join()
end = time.time()

print(f"Amount of time taken:\n{end - start:.2f}")