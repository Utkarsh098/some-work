import threading, time

def preparing_chai():
    print(f"Mixing chai ingredients...")
    time.sleep(1)
    print(f"Boiling Chai...")
    time.sleep(3)
    print(f"Chai is ready!")

def preparing_breakfast():
    print(f"Starting the preparation...")
    print(f"heating the Oven...")
    time.sleep(3)
    print(f"putting the bun inside...")
    time.sleep(2)
    print(f"Bun is ready!")
    
chai_preparation = threading.Thread(target=preparing_chai)
bun_preparation = threading.Thread(target=preparing_breakfast)

start = time.time()
chai_preparation.start()
bun_preparation.start()
chai_preparation.join()
bun_preparation.join()
end = time.time()

print(f"Your breakfast is ready!!!\ntime taken to prepare breakfast = {end-start:.2f}")
    
