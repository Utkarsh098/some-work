import requests, time, threading

BASE_URL = 'https://httpbin.org/image/'

def download_image(url):
    try:
        resp = requests.get(url, verify=False)
        data_size = round(len(resp.content), 2)
        print(f"The size for {url.split("/")[-1]} is {(data_size/1024):.2f}KB")
    
    except requests.ConnectionError as e:
        print(f"ERROR: {e}")
        
    except:
        print("An error occured...")
        
urls = [
    "jpeg",
    "png",
    "svg",
    "webp",
    ]

threads = []

start = time.time()

for url in urls:
    t = threading.Thread(target=download_image, args=(BASE_URL+url, ))
    t.start()
    threads.append(t)
    
for t in threads:
    t.join()
    
end = time.time()

print(f"total time taken is {end-start:.2f}seconds")