import threading

counter = 0
lock = threading.Lock()         #creating a lock object

def increment_counter():
    global counter
    for _ in range(100000):
        with lock:          # Ensures that no other thread makes changes to this variable in memory
            counter+=1
    

threads = [threading.Thread(target=increment_counter) for _ in range(8)]
[t.start() for t in threads]
[t.join() for t in threads]


print(f"Final Counter:\n{counter}")