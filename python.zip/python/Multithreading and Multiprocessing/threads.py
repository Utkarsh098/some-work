import time
import threading

def taking_order():
    for i in range(1,10):
        print(f"Taking order for #{i}")
        time.sleep(1)
        
def brewing_chai():
    for i in range(1,10):
        print(f"brewing chai for #{i}")
        time.sleep(3)

#threads
order_thread = threading.Thread(target=taking_order)
brewing_thread = threading.Thread(target=brewing_chai)

order_thread.start()
brewing_thread.start()

order_thread.join()
brewing_thread.join()