from multiprocessing import Process
import time

def using_Multiprocessing():
    print(f"started the Process")
    count = 0
    for i in range(1_000_000_000):              #mutex is ignored here
        count+=1
    print(f"finished the Process with count = {count}")

p1 = Process(target= using_Multiprocessing, name="P1")
p2 = Process(target= using_Multiprocessing, name="P2")

if __name__ == "__main__":
    start = time.time()
    p1.start()
    p2.start()
    p1.join()
    p2.join()
    end = time.time()
    print(f"Amount of time taken:\n{end-start:.2f}")
    