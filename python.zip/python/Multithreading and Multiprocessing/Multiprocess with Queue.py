# ==========SLOWER WITH THREADING=================

import threading, time

def Crunch_numbers():
    count = 0
    print("Crunching numbers")
    for i in range(10**7):
        count+=1
    print(count)


threads = [threading.Thread(target=Crunch_numbers) for _ in range(2)]

start = time.time()
[t.start() for t in threads]
[t.join() for t in threads]

print(f"Time taken = {time.time() - start:.2f}seconds")


# ==========FASTER WITH MULTI - PROCESSING=================

from multiprocessing import Process
import time

def Crunch_numbers():
    count = 0
    print("Crunching numbers")
    for i in range(10**7):
        count+=1
    print(count)


processes = [Process(target=Crunch_numbers) for _ in range(2)]

if __name__ == "__main__":
    start = time.time()
    [p.start() for p in processes]
    [p.join() for p in processes]
    print(f"Time taken = {time.time() - start:.2f}seconds")

# BEST METHOD USING QUEUES

from multiprocessing import Process, Queue
import time

def increment_counter(queue):
    count = 0
    for _ in range(10**7):
        count+=1
    queue.put(count)
    
if __name__ == "__main__":
    start = time.time()
    q = Queue()
    processes = [Process(target=increment_counter, args=(q, ))]
    [p.start() for p in processes]
    [p.join() for p in processes]
    print(f"{q.get()}")
    print(f"Time taken in total:\n{time.time()-start:.2f}")
    

# ANOTHER METHOD WITH VALUE(key, value) data type


from multiprocessing import Process, Value

def increment_counter(counter):
    for _ in range(10000):
        with counter.get_lock():
            counter.value+=1
    print(f"{counter.value}")
    
if __name__ == "__main__":
    count = Value("i", 0)
    processes = [Process(target=increment_counter, args=(count, )) for _ in range(4)]
    [p.start() for p in processes]
    [p.join() for p in processes]
    
    print(f"Final Counter value:{count.value}")