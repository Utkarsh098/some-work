class TeaLeaf:
    def __init__(self, age):
        self._age = age         #here _age means that there is more to this "age" property, it should not be accessed directly
        
    @property                   #age has become a property here
    def age(self):
        return self._age+2
    
    @age.setter                 #setter for age property
    def age(self, age):
        if 1 <= age <= 5:
            self._age = age
        else: 
            raise ValueError("Age should be between 1 to 5 Years")
        
        
leaf = TeaLeaf(8)
leaf.age = 6
print(leaf.age)