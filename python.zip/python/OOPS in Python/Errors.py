def My_function(name, quantity):
    try:
        print(f"Searching for {name} in your db...")
        price = {'utkarsh': 500, 'uttu': 1000}[name]
        cost = price*int(quantity)
    except ValueError as e:
        print(f"That Quantity is not in integer..\n{e}")
    except KeyError:
        print(f"That product does not exist..:")
    else:    
        print(f"Your total amount for {name} is: {cost}")
    
    

My_function("utkarsh", 3)
My_function("sadgasg", 3)
My_function("uttu", "three")
My_function("uttu", "5")