class ChaiSuper:
    def __init__(self, type_, size, sweetness):
        self.type = type_
        self.size = size
        self.sweetness = sweetness
       
    @classmethod    
    def from_dict(cls, order_data):
        return cls(
            order_data["type_"],
            order_data["size"],
            order_data["sweetness"]
        )
        
    @classmethod
    def from_string(cls, string_data):
        dataList = [data for data in string_data.split("-")]
        type_,size, sweetness = dataList
        return cls(type_, size, sweetness)
    
    
class static_methods(ChaiSuper):
    @staticmethod
    def is_valid_size(size):
        return size in ["Small", "Medium", "Large"]
        
order1 = ChaiSuper.from_dict({"type_":"Ginger", "size": "Large", "sweetness": "Mild"})
order2 = ChaiSuper.from_string("Elaichi-Small-Extreme")
order3 = ChaiSuper("Cardamom", "Medium", "No-Sugar")

print(order1.__dict__)
print(order2.__dict__)
print(order3.__dict__)

print(f"Order 1 is valid in size? \n {static_methods.is_valid_size(order1.size)}, it is {order1.size}")
print(f"Order 2 is valid in size? \n {static_methods.is_valid_size(order2.size)}, it is {order2.size}")
print(f"Order 3 is valid in size? \n {static_methods.is_valid_size(order3.size)}, it is {order3.size}")