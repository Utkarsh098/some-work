class ChaiCup:
    def __init__(self, type_, size, person):
        self.size = size
        self.type = type_
        self.person = person
        
    def describe(self):
        if self.type.startswith(("A","E","I","O","U")):
            article = "an"
        else:
            article = "a"
        return f"Ordered {article} {self.type} chai of {self.size}ml for {self.person}"
    

order1 = ChaiCup("Masala", 200, "Utkarsh")
order2 = ChaiCup("Oolong", 250, "Uttu")
order3 = ChaiCup("Tulsi", 100, "Tinny")

print(ChaiCup.describe(order1))
print(ChaiCup.describe(order2))
print(ChaiCup.describe(order3))