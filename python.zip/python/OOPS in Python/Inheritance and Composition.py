class BaseChai:
    def __init__(self, type_):
        self.type = type_
        
    def prepare(self, user):
        return f"Preparing one {self.type} chai for {user}" 
    

class inheritedChai(BaseChai):  #inheritance example
    def add_spices(self):
        return f"Adding all the extra spices"
        

chai1 = inheritedChai("Masala")
print(chai1.prepare("UttU"))
print(chai1.add_spices())


class Chaishop:
    chaiShop = BaseChai  #Composition (Just taking a reference of the class)
    
    def __init__(self):
        self.chai = self.chaiShop("Oolong")  #finally creating an instance of the baseClass with type = Oolong
                                            ## Here "chai" will have access to all the properties/ methods of the baseClass
        
    def serve(self):
        return f"Serving {self.chai.type}"
    
    
shop = Chaishop()
print(shop.serve())
print(shop.chai.prepare("Uttu"))        #shop.chai because chai (instance of the base class) has the access to the method here