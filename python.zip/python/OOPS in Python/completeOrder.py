class InvalidChaiError(Exception): pass
class InvalidCupsError(Exception): pass

def bill(flavor, cups):
    menu = {"masala": 20,
            "ginger": 25,
            "cardamom": 20
            }
    try:
        if flavor not in menu:
            raise InvalidChaiError(f"This flavor ({flavor}) is not yet available.. Please try again later.")
        
        if type(cups) != int:
            raise InvalidCupsError(f"Mention the amount of cups as number, you have entered {cups}")
        
    except Exception as e:
        print("Error:", e)
        
    else: print(f"Your {flavor} chai is ready with a total amount to be paid of {menu[flavor]*cups} rupees")
    
    finally:
        print("Thanks for visiting Uttu's Cafe")
        
bill("masala", 30)
bill("uttu", 30)
bill("cardamom", "twenty")