class Utkarsh:          #Base Class
    def __init__(self, nickName, age, type_):     #Constructor method
        self.nickName = nickName
        self.age = age
        self.type = type_
        
class UttU(Utkarsh):            #inherits the class
    def __init__(self, nickName, age, type_, sport):      #constructor method
        super().__init__(nickName, age, type_)      #Accessing the properties from the base class
        # Utkarsh.__init__(nickName, age, type_)      #Accessing the properties from the base class (Explicit call)
        self.sport = sport                          #adding additional properties