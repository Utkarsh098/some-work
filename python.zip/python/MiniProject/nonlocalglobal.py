chai_type = "ginger"

def func():
    chai_type = "tulsi"
    def kitchen():
        nonlocal chai_type 
        print(f"{chai_type}")
        chai_type = "meethi"
        print(f"{chai_type}")
    kitchen()
        
print(f"Before execution")        
print(f"{chai_type}")        
print(f"After execution")        
func()      
print(f"Global: {chai_type}")        