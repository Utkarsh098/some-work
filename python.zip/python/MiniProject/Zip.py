names = ["Utkarsh", "Tinny", "Uttu"]
cost = [200, 100, 500]

for x, y in zip(names, cost):
    print(f"{x} has {y} Rupees")
    
