types = ["masala", "kasturi", "cardamom", "ginger", "lemon"]

if (input:= input("Enter your desired chai type:\n").lower()) in types:
    print(f"{input} is available for you to order")
    
else: print(f"Sorry, {input} is not available")