users = [
    {"id": 1, "total": 150, "coupon":"FLAT10"},
    {"id": 2, "total": 200, "coupon":"FLAT15"},
    {"id": 3, "total": 300, "coupon":"FLAT20"},
]

discounts = {
    "FLAT10": (0.1, 0),
    "FLAT15": (0.15, 0),
    "FLAT20": (0.2, 10),
}

for user in users:
    percent, fixed = discounts.get(user['coupon'], (0,0))
    discount = user['total']*percent + fixed
    print(f"User {user['id']} Shopped for a total of {user['total']} and got a discount of {discount} rupees.")