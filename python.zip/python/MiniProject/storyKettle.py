choice = input("Enter your favourite beverage:\n").lower()
size = input(f"What size would you like your {choice} to be?\n").lower()

if choice == "coffee":
    if size == "small":
        print(f"Please pay 1$ for your {size} {choice}")
    elif size == "medium":
        print(f"Please pay 2$ for your {size} {choice}")
    elif size == "large":
        print(f"Please pay 5$ for your {size} {choice}")
    else: print("Enter a valid Size")
elif choice == "tea":
    if size == "small":
        print(f"Please pay 0.75$ for your {size} {choice}")
    elif size == "medium":
        print(f"Please pay 1.25$ for your {size} {choice}")
    elif size == "large":
        print(f"Please pay 2$ for your {size} {choice}")
    else: print("Enter a valid Size")
    
else: print("Please have some refreshment, dont go empty handed")