def func(*args, **keywordArgs):
    print("Normal args", args)
    print("Extra Keyword args", keywordArgs)

func("Utkarsh", "Uttu", name="Tinny", gamertag="UttUXO")

# Normal args ('Utkarsh', 'Uttu')
# Extra Keyword args {'name': 'Tinny', 'gamertag': 'UttUXO'}