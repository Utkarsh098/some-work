def calculateVat(price, vat_rate):
    return price*(1+(vat_rate/100))

prices = [100, 120, 150, 98]

for price in prices:
    final_amount = round(calculateVat(price, 10))
    print(f"The initial amount was {price}, and after adding 10% VAT, the final amount is {final_amount}")