price = int(input("Enter the amount to be paid:\n"))
deliveryfee = 30 if price < 300 else 0

print("Congratulations! You have unlocked free delivery" if deliveryfee == 0 else "Please pay 30 rupees")