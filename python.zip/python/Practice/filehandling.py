with open("Test.txt") as file:
    # file.write("Hellooo this is UttU")
    test = file.readlines(-1)
    file.seek(5, 0)
    
print(test)