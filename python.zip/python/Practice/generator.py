# def gen_function():
#     yield "this is First iteration"
#     yield "this is Second iteration"
#     yield "this is Third iteration"
#     yield "this is Fourth iteration"
#     return None

# result = gen_function()
# print(next(result))
# print(next(result))
# print(next(result))
# print(next(result))


# Result #

# this is First iteration
# this is Second iteration
# this is Third iteration
# this is Fourth iteration
# Traceback (most recent call last):
#   File "C:\Users\10735329\OneDrive - LTIMindtree\Desktop\Stuff\GenAI\python\Practice\generator.py", line 13, in <module>
#     print(next(result))
#           ~~~~^^^^^^^^
# StopIteration



# Infinite Generators and sending value to generator

# def chai_order():
#     print("Welcome to our restaurant, what would you like?")
#     chai_order = yield
#     while True:
#         print(f"{chai_order}")
#         chai_order = yield  #important for stopping iterations
        
# stall = chai_order()
# next(stall)  #starts the generator
# stall.send("Masala Chai")  #sends value to the generator


def indian_chai():
    yield "laung Chai"
    yield "Ginger Chai"
    
def exotic_chai():
    yield "Cardamom Chai"
    yield "Oolong Chai"
    
    
def total_chai():
    yield from indian_chai()
    yield from exotic_chai()
    
chai_stall = total_chai()

try:
    print(next(chai_stall))
    print(next(chai_stall))
    print(next(chai_stall))
    print(next(chai_stall))
    print(next(chai_stall))
except:
    print("end of generator")
    