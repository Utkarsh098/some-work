test_dict = dict(type = "item-song", name = "Second Hand Jawani", movie = "Cocktail")

test_dict2 = {}

test_dict2['item-song-copy']="First Hand Jawani"

print(f"{test_dict}")
print(f"{test_dict2}")
print(f"{test_dict2.keys()}")
print(f"{test_dict2.values()}")