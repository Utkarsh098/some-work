# List comprehensions
list = [
    "Iced tea",
    "Iced lemon tea",
    "Ginger tea",
    "Green tea",
    "garam tea",
    "thandi tea",
    "blue tea",
]

icedTeaList = [tea for tea in list if "Iced" in tea]

print(icedTeaList)

# Set Comprehension

set = {
    "Butterscotch shake": ["Butterscotch Icecream", "Milk", "Crushed Ice", "Hershey's Syrup"],
    "Kitkat shake": ["Vanilla Icecream", "Milk", "Crushed Ice", "Hershey's Syrup", "Kitkat"],
    "Vanilla shake": ["Vanilla Icecream", "Milk", "Crushed Ice", "Hershey's Syrup"],
    "Mango shake": ["Mango Icecream", "Milk", "Crushed Ice", "Mango Slices"]
}

ingredientsList = sorted({ ingredients for keys in set.values() for ingredients in keys })

print(ingredientsList)



# Dictionary Comprehension

shake_prices_inr = {
    "Butterscotch shake": 110,
    "Kitkat shake": 150,
    "Vanilla shake": 100,
    "Mango shake": 120
}

shake_prices_usd = {shake: "$" + str(round(price*1/90, 2)) for shake, price in shake_prices_inr.items()}

print(shake_prices_usd)


# Generator Comprehension

prices = [1,23,5,25,1,23,5,35,1,5,4,13,5,1,42,63]

generator = (price for price in prices if price>20)  #generates a stream which gives values one by one

print(sum(generator))
