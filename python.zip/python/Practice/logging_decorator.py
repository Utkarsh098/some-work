from functools import wraps

def decorator_function(func):
    @wraps(func)
    def wrapper_function(*args, **kwargs):
        print(f"✌️  Started the {func.__name__}")
        result = func(*args, **kwargs)
        print(f"👌 Finished the {func.__name__}")
        return result
    return wrapper_function

@decorator_function
def my_function(type, milk = "no"):
    print(f"Welcome to the logger of {type} and milk status is {milk}")
    
my_function("Arbitary Type", "yadayada")