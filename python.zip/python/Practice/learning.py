countries = ["America", "China", "Africa", "India", "Canada", "Chile"]
for c in countries:
    if c.startswith("C"):
        countries.remove(c)
        
print(f"{countries}")


nums = [234, 4, 1235, 34, 5, 68, 32, 43, -123, -12]
nums_sorted_squares = list(sorted(map(lambda n: n, nums)))

print(nums)
print(nums_sorted_squares)