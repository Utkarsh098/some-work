from functools import wraps

def auth_decorator(func):
    @wraps(func)
    def wrapper_function(role):
        if role != "admin":
            print("Please login with admin account")
            return None
        else:
            return func(role)
    return wrapper_function

@auth_decorator
def auth_login(role):
    print("Logged in as Administrator account")
    
    
role = input("Enter the role you want to login as: \n").lower()
auth_login(role)