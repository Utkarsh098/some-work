from functools import wraps
# # Decorators in python just takes your function, wraps it in itself and returns the function with some of previous execution and function, then after execution statements

# def my_decorator(func):
#     @wraps(func)   #usage of wraps
#     def wrapper():
#         """
#         This function returns anything you provide to it after going through various checks in itself.
#         """
#         print("Prior to execution of the function")
#         func()
#         print("After the execution of the function")
#     return wrapper
    
    
# @my_decorator
# def greet():
#     print("Demo of decorators")
    

# greet()
# print(greet.__name__)  #this will return wrapper unless we add an external library.