import arrow

time = arrow.utcnow()
print(f"{time}")
time.to('Hindi')

print(f"{time}")