def userDefinedFunction(param1 = 0, param2 = "val"):
    """This is the documentation of the function
    Through this we can define whatever the function is supposed to do
    
    including the parameter's purpose and what it will return, etc.
    
    This can be accessed by print(userDefinedFunction.__doc__)
    here __ is called dunder"""
    
    print(param2, param1)

print(userDefinedFunction.__doc__)
print(userDefinedFunction.__name__)
userDefinedFunction()